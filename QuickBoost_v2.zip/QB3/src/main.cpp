// ============================================================
//  QuickBoost v2.0  --  by Astro  |  discord.gg/astropti
//  Windows Gaming Optimizer  |  Space Theme
//  60+ Pro Tweaks  |  7 Categories  |  ImGui + DX11
// ============================================================
#pragma comment(lib,"d3d11.lib")
#pragma comment(lib,"d3dcompiler.lib")
#pragma comment(lib,"dxgi.lib")
#pragma comment(lib,"dwmapi.lib")
#pragma comment(lib,"advapi32.lib")
#pragma comment(lib,"version.lib")
#pragma comment(lib,"shell32.lib")

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#define _WIN32_WINNT 0x0A00

#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <dwmapi.h>
#include <shellapi.h>
#include <winreg.h>
#include <winsvc.h>
#include <string>
#include <vector>
#include <functional>
#include <algorithm>
#include <cstdint>
#include <mutex>
#include <chrono>
#include <cstdio>
#include <cmath>
#include <random>

#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"

#ifndef IM_PI
#define IM_PI 3.14159265358979323846f
#endif

#define STB_IMAGE_IMPLEMENTATION
// Supports PNG and JPEG (files may use either format)
#include "stb_image.h"
#include "astro_embedded.h"
#include "banner_embedded.h"

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND,UINT,WPARAM,LPARAM);

// ── Layout ───────────────────────────────────────────────────────────────────
static const float SB    = 112.f;   // sidebar width
static const float HDR   =  62.f;   // header height
static const float BNR   =  72.f;   // banner strip height
static const float STBAR =  26.f;   // status bar
static const float CARDH =  88.f;   // card height

// ── Space colour palette ─────────────────────────────────────────────────────
static inline ImU32 C(int r,int g,int b,int a=255){ return IM_COL32(r,g,b,a); }
static inline ImU32 CA(ImU32 c,int a){ return (c&0x00FFFFFF)|((ImU32)a<<24); }

// Background tones
#define C_WIN    C(  6,  6, 14)
#define C_SURF   C( 10, 10, 20)
#define C_CARD   C( 13, 13, 24)
#define C_CARDA  C(  8, 18, 28)   // applied card
#define C_SIDE   C(  7,  7, 16)

// Borders
#define C_BDR    C( 22, 22, 44)
#define C_BDRA   C( 30, 80,160)   // applied border

// Accent  (electric blue)
#define C_BLUE   C( 50,140,255)
#define C_TEAL   C( 45,210,145)   // applied / on
#define C_AMB    C(220,145, 30)   // warning / reboot
#define C_RED    C(220, 60, 80)

// Text
#define C_TXT    C(215,220,255)
#define C_DIM    C( 70, 80,130)
#define C_MUT    C( 28, 30, 60)

// ── Global app state ─────────────────────────────────────────────────────────
namespace G {
    ID3D11Device*            Dev   = nullptr;
    ID3D11DeviceContext*     Ctx   = nullptr;
    IDXGISwapChain*          SC    = nullptr;
    ID3D11RenderTargetView*  RTV   = nullptr;
    HWND                     Wnd   = nullptr;

    ID3D11ShaderResourceView* Logo   = nullptr;
    ID3D11ShaderResourceView* Banner = nullptr;
    int LW=0,LH=0, BW=0,BH=0;
    HICON WinIcon = nullptr;

    ImFont* FontSm = nullptr;   // 11.5px
    ImFont* FontMd = nullptr;   // 13.5px body
    ImFont* FontLg = nullptr;   // 16px  headings
    ImFont* FontXL = nullptr;   // 21px  title

    bool  Run=true, Admin=false, Modal=true;
    int   Tab=0;                // 0-6
    float T=0, DT=0;

    struct Star { float x,y,vy,sz,a,ph; };
    Star Stars[80];

    struct Toast { std::string msg; float t; bool ok; };
    std::vector<Toast> Toasts;
    std::mutex TMtx;
}

// ── System helpers ────────────────────────────────────────────────────────────
namespace Sys {
bool IsAdmin(){
    BOOL r=FALSE; PSID s=nullptr;
    SID_IDENTIFIER_AUTHORITY a=SECURITY_NT_AUTHORITY;
    if(AllocateAndInitializeSid(&a,2,SECURITY_BUILTIN_DOMAIN_RID,
        DOMAIN_ALIAS_RID_ADMINS,0,0,0,0,0,0,&s))
    { CheckTokenMembership(nullptr,s,&r); FreeSid(s); }
    return r!=FALSE;
}
bool RW(HKEY r,const char* p,const char* n,DWORD v){
    HKEY h; if(RegCreateKeyExA(r,p,0,nullptr,0,KEY_SET_VALUE,nullptr,&h,nullptr)
        !=ERROR_SUCCESS) return false;
    LONG x=RegSetValueExA(h,n,0,REG_DWORD,(BYTE*)&v,4);
    RegCloseKey(h); return x==ERROR_SUCCESS;
}
bool RR(HKEY r,const char* p,const char* n,DWORD& o){
    HKEY h; if(RegOpenKeyExA(r,p,0,KEY_QUERY_VALUE,&h)!=ERROR_SUCCESS) return false;
    DWORD t=REG_DWORD,s=4; LONG x=RegQueryValueExA(h,n,nullptr,&t,(BYTE*)&o,&s);
    RegCloseKey(h); return x==ERROR_SUCCESS;
}
bool RD(HKEY r,const char* p,const char* n){
    HKEY h; if(RegOpenKeyExA(r,p,0,KEY_SET_VALUE,&h)!=ERROR_SUCCESS) return true;
    LONG x=RegDeleteValueA(h,n); RegCloseKey(h);
    return x==ERROR_SUCCESS||x==ERROR_FILE_NOT_FOUND;
}
bool SvcDis(const char* n){
    SC_HANDLE scm=OpenSCManagerA(nullptr,nullptr,SC_MANAGER_CONNECT);
    if(!scm) return false;
    SC_HANDLE sv=OpenServiceA(scm,n,SERVICE_STOP|SERVICE_CHANGE_CONFIG);
    if(!sv){CloseServiceHandle(scm);return false;}
    ChangeServiceConfigA(sv,SERVICE_NO_CHANGE,SERVICE_DISABLED,
        SERVICE_NO_CHANGE,nullptr,nullptr,nullptr,nullptr,nullptr,nullptr,nullptr);
    SERVICE_STATUS ss{}; ControlService(sv,SERVICE_CONTROL_STOP,&ss);
    CloseServiceHandle(sv); CloseServiceHandle(scm); return true;
}
bool SvcOn(const char* n,DWORD st=SERVICE_AUTO_START){
    SC_HANDLE scm=OpenSCManagerA(nullptr,nullptr,SC_MANAGER_CONNECT);
    if(!scm) return false;
    SC_HANDLE sv=OpenServiceA(scm,n,SERVICE_START|SERVICE_CHANGE_CONFIG);
    if(!sv){CloseServiceHandle(scm);return false;}
    ChangeServiceConfigA(sv,SERVICE_NO_CHANGE,st,SERVICE_NO_CHANGE,
        nullptr,nullptr,nullptr,nullptr,nullptr,nullptr,nullptr);
    StartServiceA(sv,0,nullptr);
    CloseServiceHandle(sv); CloseServiceHandle(scm); return true;
}
bool SvcIsOff(const char* n){
    SC_HANDLE scm=OpenSCManagerA(nullptr,nullptr,SC_MANAGER_CONNECT);
    if(!scm) return false;
    SC_HANDLE sv=OpenServiceA(scm,n,SERVICE_QUERY_CONFIG);
    if(!sv){CloseServiceHandle(scm);return false;}
    BYTE buf[8192]{}; DWORD nd=0;
    QueryServiceConfigA(sv,(LPQUERY_SERVICE_CONFIGA)buf,sizeof(buf),&nd);
    bool d=((LPQUERY_SERVICE_CONFIGA)buf)->dwStartType==SERVICE_DISABLED;
    CloseServiceHandle(sv); CloseServiceHandle(scm); return d;
}
bool Run(const char* exe,const char* args,DWORD ms=12000){
    char cmd[2048];
    if(args&&args[0]) snprintf(cmd,sizeof(cmd),"\"%s\" %s",exe,args);
    else              snprintf(cmd,sizeof(cmd),"\"%s\"",exe);
    STARTUPINFOA si{sizeof(si)}; si.dwFlags=STARTF_USESHOWWINDOW; si.wShowWindow=SW_HIDE;
    PROCESS_INFORMATION pi{};
    if(!CreateProcessA(nullptr,cmd,nullptr,nullptr,FALSE,CREATE_NO_WINDOW,nullptr,nullptr,&si,&pi))
        return false;
    if(ms>0){WaitForSingleObject(pi.hProcess,ms);CloseHandle(pi.hProcess);CloseHandle(pi.hThread);}
    return true;
}
bool Netsh(const char* a) { return Run("netsh.exe",a); }
bool Powercfg(const char* a) { return Run("powercfg.exe",a); }
bool Bcdedit(const char* a) { return Run("bcdedit.exe",a); }
bool Schtask(const char* a) { return Run("schtasks.exe",a); }
bool PatchAdapters(const char* name,DWORD val,const char* filter){
    const char* cls="SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}";
    HKEY hc; if(RegOpenKeyExA(HKEY_LOCAL_MACHINE,cls,0,KEY_ENUMERATE_SUB_KEYS,&hc)!=ERROR_SUCCESS) return false;
    char s[64]; DWORD i=0,l=64; bool ok=false;
    while(RegEnumKeyExA(hc,i++,s,&l,nullptr,nullptr,nullptr,nullptr)==ERROR_SUCCESS){
        l=64; if(!strcmp(s,"Properties")) continue;
        std::string fp=std::string(cls)+"\\"+s; HKEY sh;
        if(RegOpenKeyExA(HKEY_LOCAL_MACHINE,fp.c_str(),0,KEY_QUERY_VALUE|KEY_SET_VALUE,&sh)==ERROR_SUCCESS){
            char d[256]={}; DWORD ds=256,dt=REG_SZ;
            RegQueryValueExA(sh,"DriverDesc",nullptr,&dt,(BYTE*)d,&ds);
            if(strstr(d,filter)){RegSetValueExA(sh,name,0,REG_DWORD,(BYTE*)&val,4);ok=true;}
            RegCloseKey(sh);}}
    RegCloseKey(hc); return ok;
}
std::string GPU(){
    HKEY h; const char* k="SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000";
    if(RegOpenKeyExA(HKEY_LOCAL_MACHINE,k,0,KEY_QUERY_VALUE,&h)!=ERROR_SUCCESS) return "unknown";
    char b[256]={}; DWORD s=256,t=REG_SZ;
    RegQueryValueExA(h,"DriverDesc",nullptr,&t,(BYTE*)b,&s); RegCloseKey(h);
    std::string v(b);
    if(v.find("NVIDIA")!=std::string::npos||v.find("GeForce")!=std::string::npos) return "nvidia";
    if(v.find("AMD")  !=std::string::npos||v.find("Radeon") !=std::string::npos)  return "amd";
    return "unknown";
}
uint64_t RAM(){ MEMORYSTATUSEX m={sizeof(m)};GlobalMemoryStatusEx(&m);return m.ullTotalPhys>>30; }
void Notify(const std::string& m,bool ok=true){
    std::lock_guard<std::mutex> l(G::TMtx); G::Toasts.push_back({m,3.5f,ok});
}
HICON MakeIcon(const uint8_t* data,int sz){
    int w,h,ch; uint8_t* px=stbi_load_from_memory(data,sz,&w,&h,&ch,4);
    if(!px) return nullptr;
    // Scale to 256x256 -- Windows silently drops oversized icons
    const int T=256;
    std::vector<uint32_t> sc(T*T);
    for(int y=0;y<T;y++) for(int x=0;x<T;x++){
        const uint8_t* s=px+((y*h/T)*w+(x*w/T))*4;
        sc[y*T+x]=((uint32_t)s[3]<<24)|((uint32_t)s[0]<<16)|((uint32_t)s[1]<<8)|s[2];
    }
    stbi_image_free(px);
    BITMAPV5HEADER bi={sizeof(bi)};
    bi.bV5Width=T; bi.bV5Height=-T; bi.bV5Planes=1; bi.bV5BitCount=32;
    bi.bV5Compression=BI_BITFIELDS;
    bi.bV5RedMask=0x00FF0000; bi.bV5GreenMask=0x0000FF00;
    bi.bV5BlueMask=0x000000FF; bi.bV5AlphaMask=0xFF000000;
    HDC dc=GetDC(nullptr); void* bits=nullptr;
    HBITMAP hbm=CreateDIBSection(dc,(BITMAPINFO*)&bi,DIB_RGB_COLORS,&bits,nullptr,0);
    ReleaseDC(nullptr,dc); if(!hbm) return nullptr;
    memcpy(bits,sc.data(),T*T*4);
    std::vector<uint8_t> mask((T/8)*T,0);
    HBITMAP hm=CreateBitmap(T,T,1,1,mask.data());
    ICONINFO ii={TRUE,0,0,hm,hbm};
    HICON ic=CreateIconIndirect(&ii);
    DeleteObject(hbm); DeleteObject(hm); return ic;
}
} // Sys

// ── Optimisation record ───────────────────────────────────────────────────────
struct Opt {
    const char *id,*name,*desc;   // desc = one-line plain English, NO special chars
    float lo,hi;
    const char* gpu;    // ""|"nvidia"|"amd"
    bool reboot,risky;
    const char* caution;
    std::function<bool()> apply,revert,check;
    mutable bool _read=false,_on=false;
};

// ── NETWORK (12 tweaks) ───────────────────────────────────────────────────────
static std::vector<Opt> MakeNet(){
    std::vector<Opt> v;
    v.push_back({"nagle","Disable Nagle Algorithm",
        "Sends TCP packets immediately instead of batching them. Cuts per-packet latency by up to 20ms.",
        1,3,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters","TcpNoDelay",1)&&
                  Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters","TcpAckFrequency",1);},
        []{Sys::RD(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters","TcpNoDelay");
           Sys::RD(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters","TcpAckFrequency");return true;},
        []{DWORD v=0;return Sys::RR(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters","TcpNoDelay",v)&&v==1;}
    });
    v.push_back({"heuristics","Disable TCP Receive-Window Heuristics",
        "Locks TCP window scaling to a fixed value. Eliminates autotuning-caused ping spikes.",
        1,2,"",false,false,"",
        []{return Sys::Netsh("int tcp set heuristics disabled");},
        []{return Sys::Netsh("int tcp set heuristics enabled");},
        []{return false;}
    });
    v.push_back({"throttle","Remove Multimedia Network Throttle",
        "Removes the 10 packets-per-ms Windows cap. Full bandwidth available to game sockets.",
        1,3,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile","NetworkThrottlingIndex",0xFFFFFFFF);},
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile","NetworkThrottlingIndex",10);},
        []{DWORD v=10;Sys::RR(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile","NetworkThrottlingIndex",v);return v==0xFFFFFFFF;}
    });
    v.push_back({"probe","Disable Network Active Probing",
        "Stops Windows from pinging Microsoft servers in the background. Removes mid-game ping spikes.",
        0.5f,1.5f,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\ControlSet001\\Services\\NlaSvc\\Parameters\\Internet","EnableActiveProbing",0);},
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\ControlSet001\\Services\\NlaSvc\\Parameters\\Internet","EnableActiveProbing",1);},
        []{DWORD v=1;Sys::RR(HKEY_LOCAL_MACHINE,"SYSTEM\\ControlSet001\\Services\\NlaSvc\\Parameters\\Internet","EnableActiveProbing",v);return v==0;}
    });
    v.push_back({"dns","Set DNS to Cloudflare 1.1.1.1",
        "Fastest public DNS resolver globally. Cuts DNS lookup time from ~40ms to ~10ms.",
        0.5f,2,"",false,false,"",
        []{Sys::Netsh("interface ipv4 set dnsservers \"Ethernet\" static 1.1.1.1 primary");
           Sys::Netsh("interface ipv4 add dnsservers \"Ethernet\" 1.0.0.1 index=2");
           Sys::Netsh("interface ipv4 set dnsservers \"Wi-Fi\" static 1.1.1.1 primary");
           Sys::Netsh("interface ipv4 add dnsservers \"Wi-Fi\" 1.0.0.1 index=2");
           return true;},
        []{Sys::Netsh("interface ipv4 set dnsservers \"Ethernet\" dhcp");
           Sys::Netsh("interface ipv4 set dnsservers \"Wi-Fi\" dhcp");return true;},
        []{return false;}
    });
    v.push_back({"tcpstack","Tune TCP Global Stack",
        "Disables ECN and timestamps. Sets CTCP congestion provider. Lowers per-packet CPU overhead.",
        1,3,"",false,false,"",
        []{Sys::Netsh("int tcp set global congestionprovider=ctcp");
           Sys::Netsh("int tcp set global ecncapability=disabled");
           Sys::Netsh("int tcp set global timestamps=disabled");
           Sys::Netsh("int tcp set global rss=enabled");return true;},
        []{Sys::Netsh("int tcp set global congestionprovider=default");
           Sys::Netsh("int tcp set global ecncapability=default");
           Sys::Netsh("int tcp set global timestamps=default");return true;},
        []{return false;}
    });
    v.push_back({"ipv6","Disable IPv6",
        "Disables IPv6 protocol stack. Reduces protocol overhead on IPv4-only gaming networks.",
        0.5f,1.5f,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Services\\Tcpip6\\Parameters","DisabledComponents",0xFF);},
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Services\\Tcpip6\\Parameters","DisabledComponents",0);},
        []{DWORD v=0;Sys::RR(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Services\\Tcpip6\\Parameters","DisabledComponents",v);return v==0xFF;}
    });
    v.push_back({"qos","Disable QoS Non-Best-Effort Limit",
        "Removes the 20 percent bandwidth reservation Windows keeps for itself. All bandwidth goes to apps.",
        1,2,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\Psched","NonBestEffortLimit",0);},
        []{return Sys::RD(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\Psched","NonBestEffortLimit");},
        []{DWORD v=1;Sys::RR(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\Psched","NonBestEffortLimit",v);return v==0;}
    });
    v.push_back({"irpstack","Increase Network IRPStackSize",
        "Increases the I/O request stack size for network operations. Prevents packet drops under load.",
        0.5f,1.5f,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Services\\LanmanServer\\Parameters","IRPStackSize",30);},
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Services\\LanmanServer\\Parameters","IRPStackSize",15);},
        []{DWORD v=0;Sys::RR(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Services\\LanmanServer\\Parameters","IRPStackSize",v);return v==30;}
    });
    v.push_back({"autotune","Disable TCP Auto-Tuning",
        "Disables Windows automatic TCP receive-window adjustment. Gives stable consistent latency.",
        1,2,"",false,false,"",
        []{return Sys::Netsh("int tcp set global autotuninglevel=disabled");},
        []{return Sys::Netsh("int tcp set global autotuninglevel=normal");},
        []{return false;}
    });
    v.push_back({"chimney","Disable TCP Chimney Offload",
        "Forces TCP processing through the CPU instead of NIC firmware. More predictable latency.",
        0.5f,1.5f,"",false,false,"",
        []{return Sys::Netsh("int tcp set global chimney=disabled");},
        []{return Sys::Netsh("int tcp set global chimney=enabled");},
        []{return false;}
    });
    v.push_back({"rto","Optimize TCP Initial RTO",
        "Sets TCP retransmission timeout to 1000ms. Faster recovery from dropped packets.",
        0.5f,1.5f,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters","InitialRto",1000);},
        []{return Sys::RD(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters","InitialRto");},
        []{DWORD v=0;Sys::RR(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters","InitialRto",v);return v==1000;}
    });
    return v;
}

// ── GPU (9 tweaks) ────────────────────────────────────────────────────────────
static std::vector<Opt> MakeGPU(){
    std::vector<Opt> v;
    v.push_back({"mpo","Disable Multiplane Overlay",
        "Fixes DWM stutter and frame-time spikes caused by MPO. Proven fix on NVIDIA + Windows 11.",
        2,5,"",true,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\Dwm","OverlayTestMode",5);},
        []{return Sys::RD(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\Dwm","OverlayTestMode");},
        []{DWORD v=0;return Sys::RR(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\Dwm","OverlayTestMode",v)&&v==5;}
    });
    v.push_back({"gpupreempt","Disable GPU Scheduler Preemption",
        "Prevents Windows from interrupting the GPU mid-frame. Eliminates micro-stutter in all games.",
        1,3,"",true,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Scheduler","DisablePreemption",1);},
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Scheduler","DisablePreemption",0);},
        []{DWORD v=0;Sys::RR(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers\\Scheduler","DisablePreemption",v);return v==1;}
    });
    v.push_back({"hags","Disable Hardware Accelerated GPU Scheduling",
        "Reverts GPU scheduling to the classic model. Reduces input latency on most DX11 and DX12 games.",
        1,3,"",true,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers","HwSchMode",1);},
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers","HwSchMode",2);},
        []{DWORD v=0;Sys::RR(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers","HwSchMode",v);return v==1;}
    });
    v.push_back({"nvmem","Contiguous GPU Memory (NVIDIA)",
        "Forces VRAM allocation in contiguous blocks. Reduces fragmentation and improves GPU throughput.",
        1,3,"nvidia",true,false,"",
        []{return Sys::PatchAdapters("PreferSystemMemoryContiguous",1,"NVIDIA")||
                  Sys::PatchAdapters("PreferSystemMemoryContiguous",1,"GeForce");},
        []{return Sys::PatchAdapters("PreferSystemMemoryContiguous",0,"NVIDIA")||
                  Sys::PatchAdapters("PreferSystemMemoryContiguous",0,"GeForce");},
        []{DWORD v=0;return Sys::RR(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000","PreferSystemMemoryContiguous",v)&&v==1;}
    });
    v.push_back({"ulps","Disable ULPS (AMD)",
        "Stops the AMD GPU from entering micro-sleep states between frames. Eliminates stutter spikes.",
        1,3,"amd",false,false,"",
        []{return Sys::PatchAdapters("EnableUlps",0,"AMD")||Sys::PatchAdapters("EnableUlps",0,"Radeon");},
        []{return Sys::PatchAdapters("EnableUlps",1,"AMD")||Sys::PatchAdapters("EnableUlps",1,"Radeon");},
        []{DWORD v=1;Sys::RR(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0000","EnableUlps",v);return v==0;}
    });
    v.push_back({"fso","Disable Fullscreen Optimizations",
        "Forces true exclusive fullscreen mode. Removes the DWM overlay that adds input lag.",
        1,3,"",false,false,"",
        []{return Sys::RW(HKEY_CURRENT_USER,"System\\GameConfigStore","GameDVR_FSEBehaviorMode",2);},
        []{return Sys::RW(HKEY_CURRENT_USER,"System\\GameConfigStore","GameDVR_FSEBehaviorMode",0);},
        []{DWORD v=0;Sys::RR(HKEY_CURRENT_USER,"System\\GameConfigStore","GameDVR_FSEBehaviorMode",v);return v==2;}
    });
    v.push_back({"dontthrottle","Disable DWM Throttling",
        "Prevents the Desktop Window Manager from reducing GPU resources when the game is in focus.",
        0.5f,2,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile","SystemResponsiveness",0);},
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile","SystemResponsiveness",20);},
        []{DWORD v=20;Sys::RR(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile","SystemResponsiveness",v);return v==0;}
    });
    v.push_back({"gpuprio","Boost GPU Process Priority",
        "Sets the GPU scheduling priority to 8 for game processes. More consistent frame delivery.",
        1,2,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games","GPU Priority",8);},
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games","GPU Priority",2);},
        []{DWORD v=2;Sys::RR(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games","GPU Priority",v);return v==8;}
    });
    v.push_back({"hdcp","Disable HDCP",
        "Disables the HDCP copy-protection handshake. Removes the per-frame GPU overhead it causes.",
        0.5f,1.5f,"",false,false,"",
        []{return Sys::PatchAdapters("RMHdcpKeyglobZero",1,"NVIDIA")||
                  Sys::PatchAdapters("RMHdcpKeyglobZero",1,"GeForce");},
        []{return Sys::PatchAdapters("RMHdcpKeyglobZero",0,"NVIDIA")||
                  Sys::PatchAdapters("RMHdcpKeyglobZero",0,"GeForce");},
        []{return false;}
    });
    return v;
}

// ── CPU (9 tweaks) ────────────────────────────────────────────────────────────
static std::vector<Opt> MakeCPU(){
    std::vector<Opt> v;
    v.push_back({"powerplan","Enable Ultimate Performance Power Plan",
        "Unlocks and activates the hidden Ultimate Performance plan. Removes all CPU clock throttling.",
        5,15,"",false,false,"",
        []{Sys::Powercfg("-duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61");
           return Sys::Powercfg("-setactive e9a42b02-d5df-448d-aa00-03f14749eb61");},
        []{return Sys::Powercfg("-setactive 381b4222-f694-41f0-9685-ff5bb260df2e");},
        []{return false;}
    });
    v.push_back({"hpet","Disable HPET - Use TSC Timer",
        "Forces Windows to use the CPU TSC counter instead of HPET. Lower timer overhead and latency.",
        1,3,"",true,false,"",
        []{Sys::Bcdedit("/deletevalue useplatformclock");Sys::Bcdedit("/set useplatformtick yes");
           return Sys::Bcdedit("/set disabledynamictick yes");},
        []{Sys::Bcdedit("/set useplatformclock true");return Sys::Bcdedit("/deletevalue disabledynamictick");},
        []{return false;}
    });
    v.push_back({"coreparking","Disable CPU Core Parking",
        "Prevents Windows from putting CPU cores into a parked idle state. All cores stay ready instantly.",
        2,5,"",false,false,"",
        []{Sys::Powercfg("-setacvalueindex SCHEME_CURRENT 54533251-82be-4824-96c1-47b60b740d00 0cc5b647-c1df-4637-891a-dec35c318583 100");
           return Sys::Powercfg("-S SCHEME_CURRENT");},
        []{Sys::Powercfg("-setacvalueindex SCHEME_CURRENT 54533251-82be-4824-96c1-47b60b740d00 0cc5b647-c1df-4637-891a-dec35c318583 0");
           return Sys::Powercfg("-S SCHEME_CURRENT");},
        []{return false;}
    });
    v.push_back({"cpuidle","Disable CPU Idle States",
        "Stops CPU from entering deep C-states. Eliminates the wakeup latency when a game needs a core.",
        1,3,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Power","CsEnabled",0);},
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Power","CsEnabled",1);},
        []{DWORD v=1;Sys::RR(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Power","CsEnabled",v);return v==0;}
    });
    v.push_back({"kernpoll","Kernel Debug Poll Interval",
        "Sets DebugPollInterval to 1000. Reduces kernel interrupt frequency and frame-time variance.",
        0.5f,1.5f,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Kernel","DebugPollInterval",1000);},
        []{return Sys::RD(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Kernel","DebugPollInterval");},
        []{DWORD v=0;return Sys::RR(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Kernel","DebugPollInterval",v)&&v==1000;}
    });
    v.push_back({"drvsearch","Disable Automatic Driver Search",
        "Stops Windows from auto-installing drivers mid-session. Prevents unexpected stutters.",
        0.5f,1.5f,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\DriverSearching","SearchOrderConfig",0);},
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\DriverSearching","SearchOrderConfig",1);},
        []{DWORD v=1;Sys::RR(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\DriverSearching","SearchOrderConfig",v);return v==0;}
    });
    v.push_back({"sysres","System Responsiveness for Games",
        "Sets SystemResponsiveness to 0. Dedicates maximum CPU resources to the foreground game process.",
        1,2,"",false,false,"",
        []{Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile","SystemResponsiveness",0);
           return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile","SystemResponsiveness",0);},
        []{Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile","SystemResponsiveness",20);return true;},
        []{DWORD v=20;Sys::RR(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile","SystemResponsiveness",v);return v==0;}
    });
    v.push_back({"prio","Boost Game CPU Priority",
        "Sets game task scheduling category to High in the multimedia profile. More CPU time for games.",
        1,3,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games","Priority",6);},
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games","Priority",2);},
        []{DWORD v=0;Sys::RR(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games","Priority",v);return v==6;}
    });
    v.push_back({"visuals","Disable Windows Visual Effects",
        "Turns off all UI animations, transparency and shadows. Frees CPU cycles for your game.",
        1,3,"",false,false,"",
        []{return Sys::RW(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\VisualEffects","VisualFXSetting",2);},
        []{return Sys::RW(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\VisualEffects","VisualFXSetting",0);},
        []{DWORD v=0;Sys::RR(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\VisualEffects","VisualFXSetting",v);return v==2;}
    });
    return v;
}

// ── MEMORY (7 tweaks) ─────────────────────────────────────────────────────────
static std::vector<Opt> MakeMem(){
    std::vector<Opt> v;
    v.push_back({"sysmain","Disable SysMain (Superfetch)",
        "Stops Windows from preloading apps into RAM. Frees memory for your game and removes I/O spikes.",
        1,4,"",false,false,"",
        []{return Sys::SvcDis("SysMain");},
        []{return Sys::SvcOn("SysMain");},
        []{return Sys::SvcIsOff("SysMain");}
    });
    v.push_back({"pagecomb","Optimize Working Set Trim",
        "Sets MinimumWorkingSetSize to allow Windows to trim idle process memory more aggressively.",
        1,2.5f,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management","DisablePagingExecutive",0);},
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management","DisablePagingExecutive",1);},
        []{DWORD v=1;Sys::RR(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management","DisablePagingExecutive",v);return v==0;}
    });
    v.push_back({"memcomp","Disable Paging Executive",
        "Keeps kernel and drivers in physical RAM instead of paging to disk. Removes kernel paging latency.",
        0.5f,2,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management","DisablePagingExecutive",1);},
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management","DisablePagingExecutive",0);},
        []{DWORD v=0;Sys::RR(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management","DisablePagingExecutive",v);return v==1;}
    });
    v.push_back({"largecache","Disable Large System Cache",
        "Prevents Windows from using excess RAM as file cache. Keeps more RAM available for your game.",
        0.5f,2,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management","LargeSystemCache",0);},
        []{return Sys::RD(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management","LargeSystemCache");},
        []{DWORD v=1;Sys::RR(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management","LargeSystemCache",v);return v==0;}
    });
    v.push_back({"prefetch","Disable Prefetch",
        "Stops Windows from preloading apps into RAM ahead of time. Reduces background I/O interference.",
        0.5f,1.5f,"",false,false,"",
        []{bool ok=Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters","EnablePrefetcher",0);
           ok&=Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters","EnableSuperfetch",0);
           return ok;},
        []{Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters","EnablePrefetcher",3);
           return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters","EnableSuperfetch",3);},
        []{DWORD v=3;Sys::RR(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters","EnablePrefetcher",v);return v==0;}
    });
    v.push_back({"pagefile","Clear Page File at Shutdown",
        "Wipes the paging file on every clean shutdown. Prevents stale data from slowing the next boot.",
        0.5f,1,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management","ClearPageFileAtShutdown",1);},
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management","ClearPageFileAtShutdown",0);},
        []{DWORD v=0;Sys::RR(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management","ClearPageFileAtShutdown",v);return v==1;}
    });
    v.push_back({"nonpaged","Optimize NonPaged Pool",
        "Increases the non-paged pool size to improve kernel memory allocation performance.",
        0.5f,1.5f,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management","NonPagedPoolSize",0xFFFFFFFF);},
        []{return Sys::RD(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management","NonPagedPoolSize");},
        []{DWORD v=0;Sys::RR(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management","NonPagedPoolSize",v);return v==0xFFFFFFFF;}
    });
    return v;
}

// ── STORAGE (6 tweaks) ────────────────────────────────────────────────────────
static std::vector<Opt> MakeStorage(){
    std::vector<Opt> v;
    v.push_back({"wsearch","Disable Windows Search Indexer",
        "Stops constant background file indexing. Removes disk thrashing that causes micro-stutters.",
        1,3,"",false,false,"",
        []{return Sys::SvcDis("WSearch");},
        []{return Sys::SvcOn("WSearch");},
        []{return Sys::SvcIsOff("WSearch");}
    });
    v.push_back({"ntfs83","Disable 8.3 Filename Creation",
        "Stops NTFS from creating legacy short 8.3 filenames. Speeds up file creation operations.",
        0.5f,1.5f,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\FileSystem","NtfsDisable8dot3NameCreation",1);},
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\FileSystem","NtfsDisable8dot3NameCreation",0);},
        []{DWORD v=0;Sys::RR(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\FileSystem","NtfsDisable8dot3NameCreation",v);return v==1;}
    });
    v.push_back({"ntfslast","Disable NTFS Last Access Timestamp",
        "Stops NTFS from writing a timestamp on every file read. Significantly reduces disk write traffic.",
        1,2,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\FileSystem","NtfsDisableLastAccessUpdate",1);},
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\FileSystem","NtfsDisableLastAccessUpdate",0);},
        []{DWORD v=0;Sys::RR(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\FileSystem","NtfsDisableLastAccessUpdate",v);return v==1;}
    });
    v.push_back({"defrag","Disable Scheduled Disk Defragmenter",
        "Disables the automatic weekly defrag task. Prevents background disk access during gameplay.",
        0.5f,1.5f,"",false,false,"",
        []{return Sys::Schtask("/Change /TN \"\\Microsoft\\Windows\\Defrag\\ScheduledDefrag\" /Disable");},
        []{return Sys::Schtask("/Change /TN \"\\Microsoft\\Windows\\Defrag\\ScheduledDefrag\" /Enable");},
        []{return false;}
    });
    v.push_back({"superfetch2","Disable SysMain Memory Prefetch",
        "Disables prefetch parameters in addition to the SysMain service for complete removal.",
        0.5f,1,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters","EnableSuperfetch",0);},
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters","EnableSuperfetch",3);},
        []{DWORD v=3;Sys::RR(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters","EnableSuperfetch",v);return v==0;}
    });
    v.push_back({"ntfsencrypt","Disable NTFS Auto-Encrypt",
        "Prevents NTFS from transparently encrypting new files on the drive. Removes that CPU overhead.",
        0.5f,1,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\FileSystem","NtfsEncryptionService",0);},
        []{return Sys::RD(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\FileSystem","NtfsEncryptionService");},
        []{DWORD v=1;Sys::RR(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\FileSystem","NtfsEncryptionService",v);return v==0;}
    });
    return v;
}

// ── SYSTEM (10 tweaks) ────────────────────────────────────────────────────────
static std::vector<Opt> MakeSys(){
    std::vector<Opt> v;
    v.push_back({"gamedvr","Disable Xbox Game DVR and Game Bar",
        "Kills background game recording. Removes 2 to 5 percent GPU overhead present in every game.",
        2,5,"",false,false,"",
        []{bool ok=Sys::RW(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR","AppCaptureEnabled",0);
           ok&=Sys::RW(HKEY_CURRENT_USER,"System\\GameConfigStore","GameDVR_Enabled",0);
           ok&=Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\GameDVR","AllowGameDVR",0);
           ok&=Sys::RW(HKEY_CURRENT_USER,"Software\\Microsoft\\GameBar","UseNexusForGameBarEnabled",0);return ok;},
        []{Sys::RW(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR","AppCaptureEnabled",1);
           return Sys::RW(HKEY_CURRENT_USER,"System\\GameConfigStore","GameDVR_Enabled",1);},
        []{DWORD v=1;Sys::RR(HKEY_CURRENT_USER,"System\\GameConfigStore","GameDVR_Enabled",v);return v==0;}
    });
    v.push_back({"wer","Disable Windows Error Reporting",
        "Stops crash-dump writes to disk that spike I/O mid-game. Disables WerSvc service.",
        0.5f,1.5f,"",false,false,"",
        []{Sys::SvcDis("WerSvc");return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\Windows Error Reporting","Disabled",1);},
        []{Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\Windows Error Reporting","Disabled",0);return Sys::SvcOn("WerSvc",SERVICE_DEMAND_START);},
        []{DWORD v=0;Sys::RR(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\Windows Error Reporting","Disabled",v);return v==1;}
    });
    v.push_back({"spooler","Disable Print Spooler",
        "Removes spooler CPU polling. Only disable if no printer is connected to this machine.",
        0.5f,1,"",false,true,"Only disable if you have no printer attached.",
        []{return Sys::SvcDis("Spooler");},
        []{return Sys::SvcOn("Spooler");},
        []{return Sys::SvcIsOff("Spooler");}
    });
    v.push_back({"faststartup","Disable Fast Startup",
        "Disables hybrid boot. Ensures a full clean shutdown every time which prevents driver corruption.",
        0.5f,1,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Power","HiberbootEnabled",0);},
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Power","HiberbootEnabled",1);},
        []{DWORD v=1;Sys::RR(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Power","HiberbootEnabled",v);return v==0;}
    });
    v.push_back({"hibernate","Disable Hibernation",
        "Disables hiberfil.sys. Frees several GB of disk space and removes hibernate state interference.",
        0.5f,1,"",false,false,"",
        []{return Sys::Powercfg("-h off");},
        []{return Sys::Powercfg("-h on");},
        []{return false;}
    });
    v.push_back({"maintenance","Disable Automatic Maintenance",
        "Stops the Windows automatic maintenance task that runs in the background during gameplay.",
        0.5f,1.5f,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Schedule\\Maintenance","MaintenanceDisabled",1);},
        []{return Sys::RD(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Schedule\\Maintenance","MaintenanceDisabled");},
        []{DWORD v=0;Sys::RR(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Schedule\\Maintenance","MaintenanceDisabled",v);return v==1;}
    });
    v.push_back({"connux","Disable Connected User Experiences",
        "Kills the DiagTrack background service. Removes telemetry that competes for CPU and network.",
        0.5f,1.5f,"",false,false,"",
        []{Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection","DoNotShowFeedbackNotifications",1);
           return Sys::SvcDis("DiagTrack");},
        []{return Sys::SvcOn("DiagTrack");},
        []{return Sys::SvcIsOff("DiagTrack");}
    });
    v.push_back({"autoupdate","Disable Windows Update Auto-Download",
        "Prevents Windows Update from downloading files in the background during gaming sessions.",
        0.5f,2,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate\\AU","NoAutoUpdate",1);},
        []{return Sys::RD(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate\\AU","NoAutoUpdate");},
        []{DWORD v=0;Sys::RR(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate\\AU","NoAutoUpdate",v);return v==1;}
    });
    v.push_back({"statenotif","Disable Windows State Notifications",
        "Disables background app state change notifications. Reduces context switches during gameplay.",
        0.5f,1,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\System","DisableHiberBoot",1);},
        []{return Sys::RD(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\System","DisableHiberBoot");},
        []{DWORD v=0;Sys::RR(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\System","DisableHiberBoot",v);return v==1;}
    });
    v.push_back({"defsamples","Disable Defender Automatic Sample Submission",
        "Stops Defender from sending file samples to Microsoft cloud. Removes background upload overhead.",
        0.5f,1.5f,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows Defender\\Spynet","SubmitSamplesConsent",2);},
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows Defender\\Spynet","SubmitSamplesConsent",1);},
        []{DWORD v=1;Sys::RR(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows Defender\\Spynet","SubmitSamplesConsent",v);return v==2;}
    });
    return v;
}

// ── PRIVACY (7 tweaks) ────────────────────────────────────────────────────────
static std::vector<Opt> MakePriv(){
    std::vector<Opt> v;
    v.push_back({"telem","Disable Telemetry and CEIP",
        "Kills DiagTrack service and sets AllowTelemetry to 0. Stops all Microsoft data collection.",
        0.5f,2,"",false,false,"",
        []{Sys::SvcDis("DiagTrack");Sys::SvcDis("dmwappushservice");
           Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection","AllowTelemetry",0);
           return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\SQMClient\\Windows","CEIPEnable",0);},
        []{Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection","AllowTelemetry",1);
           Sys::SvcOn("DiagTrack");return true;},
        []{DWORD v=1;Sys::RR(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection","AllowTelemetry",v);return v==0;}
    });
    v.push_back({"activity","Disable Activity History",
        "Stops Windows from recording your app usage and browsing activity for the Timeline feature.",
        0.5f,1,"",false,false,"",
        []{Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\System","EnableActivityFeed",0);
           return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\System","PublishUserActivities",0);},
        []{Sys::RD(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\System","EnableActivityFeed");
           return Sys::RD(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\System","PublishUserActivities");},
        []{DWORD v=1;Sys::RR(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\System","EnableActivityFeed",v);return v==0;}
    });
    v.push_back({"location","Disable Location Services",
        "Completely disables the Windows location services. Prevents background location lookups.",
        0.5f,1,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\LocationAndSensors","DisableLocation",1);},
        []{return Sys::RD(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\LocationAndSensors","DisableLocation");},
        []{DWORD v=0;Sys::RR(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\LocationAndSensors","DisableLocation",v);return v==1;}
    });
    v.push_back({"adid","Disable Advertising ID",
        "Removes the unique per-user ad identifier. Stops advertiser tracking across app sessions.",
        0.5f,1,"",false,false,"",
        []{return Sys::RW(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\AdvertisingInfo","Enabled",0);},
        []{return Sys::RW(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\AdvertisingInfo","Enabled",1);},
        []{DWORD v=1;Sys::RR(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\AdvertisingInfo","Enabled",v);return v==0;}
    });
    v.push_back({"feedback","Disable Feedback Notifications",
        "Stops Windows from asking for feedback. Removes the periodic background feedback collection.",
        0.5f,1,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection","DoNotShowFeedbackNotifications",1);},
        []{return Sys::RD(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection","DoNotShowFeedbackNotifications");},
        []{DWORD v=0;Sys::RR(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection","DoNotShowFeedbackNotifications",v);return v==1;}
    });
    v.push_back({"diagdata","Disable Diagnostic Data Collection",
        "Sets diagnostic data level to Security only. Minimizes Windows data reporting overhead.",
        0.5f,1.5f,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\DataCollection","AllowTelemetry",0);},
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\DataCollection","AllowTelemetry",1);},
        []{DWORD v=1;Sys::RR(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\DataCollection","AllowTelemetry",v);return v==0;}
    });
    v.push_back({"appdiag","Disable App Diagnostics",
        "Prevents apps from accessing diagnostic data about other apps. Improves system privacy.",
        0.5f,1,"",false,false,"",
        []{return Sys::RW(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\AppPrivacy","LetAppsGetDiagnosticInfo",2);},
        []{return Sys::RD(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\AppPrivacy","LetAppsGetDiagnosticInfo");},
        []{DWORD v=0;Sys::RR(HKEY_LOCAL_MACHINE,"SOFTWARE\\Policies\\Microsoft\\Windows\\AppPrivacy","LetAppsGetDiagnosticInfo",v);return v==2;}
    });
    return v;
}

// ── DirectX 11 ────────────────────────────────────────────────────────────────
namespace DX {
void MakeRTV(){
    ID3D11Texture2D* bb=nullptr; G::SC->GetBuffer(0,IID_PPV_ARGS(&bb));
    if(bb){G::Dev->CreateRenderTargetView(bb,nullptr,&G::RTV);bb->Release();}
}
void DropRTV(){ if(G::RTV){G::RTV->Release();G::RTV=nullptr;} }
bool Init(HWND hw){
    DXGI_SWAP_CHAIN_DESC sd={};
    sd.BufferCount=2; sd.BufferDesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate={60,1}; sd.Flags=DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
    sd.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT; sd.OutputWindow=hw;
    sd.SampleDesc.Count=1; sd.Windowed=TRUE; sd.SwapEffect=DXGI_SWAP_EFFECT_DISCARD;
    D3D_FEATURE_LEVEL fl; const D3D_FEATURE_LEVEL fa[]={D3D_FEATURE_LEVEL_11_0,D3D_FEATURE_LEVEL_10_0};
    HRESULT hr=D3D11CreateDeviceAndSwapChain(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,fa,2,D3D11_SDK_VERSION,&sd,&G::SC,&G::Dev,&fl,&G::Ctx);
    if(hr==DXGI_ERROR_UNSUPPORTED)
        hr=D3D11CreateDeviceAndSwapChain(nullptr,D3D_DRIVER_TYPE_WARP,nullptr,0,fa,2,D3D11_SDK_VERSION,&sd,&G::SC,&G::Dev,&fl,&G::Ctx);
    if(FAILED(hr)) return false; MakeRTV(); return true;
}
void Kill(){
    DropRTV();
    if(G::SC){G::SC->Release();G::SC=nullptr;}
    if(G::Ctx){G::Ctx->Release();G::Ctx=nullptr;}
    if(G::Dev){G::Dev->Release();G::Dev=nullptr;}
}
bool Tex(const uint8_t* d,int s,ID3D11ShaderResourceView** srv,int* w,int* h){
    int ch; uint8_t* px=stbi_load_from_memory(d,s,w,h,&ch,4); if(!px) return false;
    D3D11_TEXTURE2D_DESC td={}; td.Width=*w; td.Height=*h; td.MipLevels=td.ArraySize=1;
    td.Format=DXGI_FORMAT_R8G8B8A8_UNORM; td.SampleDesc.Count=1;
    td.Usage=D3D11_USAGE_DEFAULT; td.BindFlags=D3D11_BIND_SHADER_RESOURCE;
    D3D11_SUBRESOURCE_DATA sr={px,(UINT)(*w*4),0};
    ID3D11Texture2D* tex=nullptr; HRESULT hr=G::Dev->CreateTexture2D(&td,&sr,&tex);
    stbi_image_free(px); if(FAILED(hr)) return false;
    D3D11_SHADER_RESOURCE_VIEW_DESC sv={}; sv.Format=td.Format;
    sv.ViewDimension=D3D11_SRV_DIMENSION_TEXTURE2D; sv.Texture2D.MipLevels=1;
    hr=G::Dev->CreateShaderResourceView(tex,&sv,srv); tex->Release(); return SUCCEEDED(hr);
}
} // DX

// ── ImGui Style ───────────────────────────────────────────────────────────────
static void SetStyle(){
    ImGuiStyle& s=ImGui::GetStyle();
    s.WindowRounding=0; s.ChildRounding=7; s.FrameRounding=5;
    s.ScrollbarRounding=4; s.GrabRounding=4; s.PopupRounding=9;
    s.WindowPadding={0,0}; s.FramePadding={10,6}; s.ItemSpacing={8,5};
    s.ScrollbarSize=6; s.GrabMinSize=4;
    s.WindowBorderSize=0; s.ChildBorderSize=0; s.FrameBorderSize=0;
    auto* C=s.Colors;
    C[ImGuiCol_WindowBg]             ={0.024f,0.024f,0.055f,1};
    C[ImGuiCol_ChildBg]              ={0.024f,0.024f,0.055f,1};
    C[ImGuiCol_PopupBg]              ={0.035f,0.035f,0.075f,0.99f};
    C[ImGuiCol_Border]               ={0.086f,0.086f,0.17f,1};
    C[ImGuiCol_FrameBg]              ={0.04f, 0.04f, 0.09f,1};
    C[ImGuiCol_FrameBgHovered]       ={0.07f, 0.07f, 0.14f,1};
    C[ImGuiCol_FrameBgActive]        ={0.10f, 0.10f, 0.20f,1};
    C[ImGuiCol_TitleBg]              ={0.024f,0.024f,0.055f,1};
    C[ImGuiCol_TitleBgActive]        ={0.030f,0.030f,0.070f,1};
    C[ImGuiCol_ScrollbarBg]          ={0.015f,0.015f,0.040f,1};
    C[ImGuiCol_ScrollbarGrab]        ={0.14f, 0.14f, 0.30f, 1};
    C[ImGuiCol_ScrollbarGrabHovered] ={0.22f, 0.22f, 0.46f, 1};
    C[ImGuiCol_ScrollbarGrabActive]  ={0.32f, 0.32f, 0.64f, 1};
    C[ImGuiCol_CheckMark]            ={0.40f, 0.85f, 0.65f, 1};
    C[ImGuiCol_Button]               ={0.07f, 0.07f, 0.16f, 1};
    C[ImGuiCol_ButtonHovered]        ={0.12f, 0.12f, 0.28f, 1};
    C[ImGuiCol_ButtonActive]         ={0.18f, 0.18f, 0.38f, 1};
    C[ImGuiCol_Header]               ={0.09f, 0.09f, 0.20f, 1};
    C[ImGuiCol_HeaderHovered]        ={0.14f, 0.14f, 0.30f, 1};
    C[ImGuiCol_Separator]            ={0.07f, 0.07f, 0.17f, 1};
    C[ImGuiCol_Text]                 ={0.84f, 0.86f, 1.00f, 1};
    C[ImGuiCol_TextDisabled]         ={0.27f, 0.31f, 0.51f, 1};
    C[ImGuiCol_ModalWindowDimBg]     ={0.00f, 0.00f, 0.00f, 0.82f};
}

// ── Drawing helpers ───────────────────────────────────────────────────────────
static void GY(ImDrawList* dl,ImVec2 a,ImVec2 b,ImU32 t,ImU32 bt){dl->AddRectFilledMultiColor(a,b,t,t,bt,bt);}
static void GX(ImDrawList* dl,ImVec2 a,ImVec2 b,ImU32 l,ImU32 r){dl->AddRectFilledMultiColor(a,b,l,r,r,l);}
static void Glow(ImDrawList* dl,ImVec2 c,float r,ImU32 col,int n=5){
    ImVec4 v=ImGui::ColorConvertU32ToFloat4(col);
    for(int i=n;i>=1;i--)
        dl->AddCircleFilled(c,r*i,C((int)(v.x*255),(int)(v.y*255),(int)(v.z*255),(int)(v.w*255*0.14f/i)));
}
static void Shadow(ImDrawList* dl,ImVec2 mn,ImVec2 mx,int n=4){
    for(int i=n;i>=1;i--){float e=i*2.5f;dl->AddRectFilled({mn.x-e,mn.y+e},{mx.x+e,mx.y+e},C(0,0,0,22/i),12.f+e);}
}
static void HSep(ImDrawList* dl,float x0,float x1,float y,int bri=20){
    dl->AddRectFilledMultiColor({x0,y},{x1,y+1},C(0,0,0,0),C(bri,bri,bri+20,255),C(bri,bri,bri+20,255),C(0,0,0,0));
}
static void Stars(ImDrawList* dl,ImVec2 origin,float W,float H){
    for(auto& s:G::Stars){
        s.y-=s.vy; if(s.y<0)s.y=H;
        s.ph=fmodf(s.ph+G::DT*.35f,1.f);
        int a=(int)(sinf(s.ph*IM_PI)*s.a*200);
        if(a>3)dl->AddCircleFilled({origin.x+s.x,origin.y+s.y},s.sz,C(180,200,255,a));
    }
}

// ── Sidebar icons ─────────────────────────────────────────────────────────────
static void I_Net(ImDrawList* dl,ImVec2 o,float sz,ImU32 c){
    float cx=o.x+sz*.5f,cy=o.y+sz*.5f;
    for(int i=3;i>=1;i--) dl->AddCircle({cx,cy},sz*.12f*i,CA(c,50+60*i),32,1.2f);
    dl->AddCircleFilled({cx,cy},sz*.06f,c);
    float by=cy+sz*.30f;
    for(int i=0;i<4;i++){float bh=sz*.08f*(i+1),bx=cx-sz*.25f+i*sz*.16f;dl->AddRectFilled({bx,by-bh},{bx+sz*.10f,by},CA(c,80+44*i),1.f);}
}
static void I_GPU(ImDrawList* dl,ImVec2 o,float sz,ImU32 c){
    float x=o.x+sz*.1f,y=o.y+sz*.25f,w=sz*.8f,h=sz*.5f;
    dl->AddRect({x,y},{x+w,y+h},c,4,0,1.5f);
    for(int i=0;i<4;i++){float px=x+w*.15f+i*w*.18f,py=y+h;dl->AddLine({px,py},{px,py+sz*.12f},c,1.5f);dl->AddLine({px-sz*.04f,py+sz*.12f},{px+sz*.04f,py+sz*.12f},c,1.5f);}
    dl->AddRectFilled({x+sz*.08f,y+sz*.10f},{x+sz*.32f,y+h-sz*.10f},CA(c,40),2.f);
}
static void I_CPU(ImDrawList* dl,ImVec2 o,float sz,ImU32 c){
    float cx=o.x+sz*.5f,cy=o.y+sz*.5f,r=sz*.30f,gap=sz*.055f;
    dl->AddRect({cx-r,cy-r},{cx+r,cy+r},c,3,0,1.5f);
    dl->AddRect({cx-r+gap,cy-r+gap},{cx+r-gap,cy+r-gap},CA(c,80),2,0,1.f);
    for(int i=0;i<4;i++){
        float p=r*(.5f-(float)i*.28f);
        dl->AddLine({cx-r-sz*.08f,cy+p},{cx-r,cy+p},c,1.4f);
        dl->AddLine({cx+r,cy+p},{cx+r+sz*.08f,cy+p},c,1.4f);
        dl->AddLine({cx+p,cy-r-sz*.08f},{cx+p,cy-r},c,1.4f);
        dl->AddLine({cx+p,cy+r},{cx+p,cy+r+sz*.08f},c,1.4f);
    }
}
static void I_Mem(ImDrawList* dl,ImVec2 o,float sz,ImU32 c){
    float x=o.x+sz*.08f,y=o.y+sz*.3f,w=sz*.84f,h=sz*.4f;
    dl->AddRect({x,y},{x+w,y+h},c,2,0,1.5f);
    for(int i=0;i<6;i++){float px=x+w*.08f+i*w*.145f;dl->AddRectFilled({px,y+h*.15f},{px+w*.08f,y+h*.85f},CA(c,120),1.f);}
    dl->AddLine({x+w*.05f,y+h},{x+w*.05f,y+h+sz*.16f},c,1.3f);
    dl->AddLine({x+w*.95f,y+h},{x+w*.95f,y+h+sz*.16f},c,1.3f);
}
static void I_Str(ImDrawList* dl,ImVec2 o,float sz,ImU32 c){
    float cx=o.x+sz*.5f,cy=o.y+sz*.5f;
    dl->AddCircle({cx,cy},sz*.36f,c,32,1.5f);
    dl->AddCircle({cx,cy},sz*.18f,CA(c,150),24,1.2f);
    dl->AddCircleFilled({cx,cy},sz*.06f,c);
    for(int i=0;i<4;i++){float a=IM_PI*.5f*i;dl->AddLine({cx+cosf(a)*sz*.18f,cy+sinf(a)*sz*.18f},{cx+cosf(a)*sz*.36f,cy+sinf(a)*sz*.36f},c,1.4f);}
}
static void I_Sys(ImDrawList* dl,ImVec2 o,float sz,ImU32 c){
    ImVec2 ctr={o.x+sz*.5f,o.y+sz*.5f}; float R=sz*.36f,r=sz*.20f,th=sz*.12f;
    for(int i=0;i<8;i++){
        float a0=IM_PI*2*i/8.f-IM_PI/8*.4f,a1=IM_PI*2*i/8.f+IM_PI/8*.4f;
        ImVec2 p0={ctr.x+cosf(a0)*R,ctr.y+sinf(a0)*R},p1={ctr.x+cosf(a1)*R,ctr.y+sinf(a1)*R};
        ImVec2 p2={ctr.x+cosf(a1)*(R+th),ctr.y+sinf(a1)*(R+th)},p3={ctr.x+cosf(a0)*(R+th),ctr.y+sinf(a0)*(R+th)};
        dl->AddQuadFilled(p0,p1,p2,p3,CA(c,170)); dl->AddQuad(p0,p1,p2,p3,c,1.f);
    }
    dl->AddCircle(ctr,R,c,64,1.4f); dl->AddCircle(ctr,r,c,32,1.8f);
}
static void I_Priv(ImDrawList* dl,ImVec2 o,float sz,ImU32 c){
    float cx=o.x+sz*.5f,ty=o.y+sz*.12f,bh=sz*.55f,bw=sz*.54f;
    // shield
    ImVec2 pts[]={{cx,ty},{cx+bw*.5f,ty+bh*.3f},{cx+bw*.5f,ty+bh*.7f},{cx,ty+bh},{cx-bw*.5f,ty+bh*.7f},{cx-bw*.5f,ty+bh*.3f}};
    dl->AddConvexPolyFilled(pts,6,CA(c,40));
    dl->AddPolyline(pts,6,c,ImDrawFlags_Closed,1.6f);
    // lock
    float lx=cx-sz*.10f,ly=ty+bh*.25f;
    dl->AddRect({lx,ly+sz*.10f},{lx+sz*.20f,ly+sz*.28f},c,2,0,1.3f);
    dl->PathArcTo({cx,ly+sz*.10f},sz*.10f,IM_PI,0.f,16); dl->PathStroke(c,false,1.3f);
}

// ── UI ────────────────────────────────────────────────────────────────────────
namespace UI {
static const char* CAT_NAMES[7]={"Network","GPU","CPU","Memory","Storage","System","Privacy"};
static const char* CAT_SUBS[7]={
    "TCP stack, DNS, latency and protocol tweaks",
    "GPU scheduler, VRAM and rendering pipeline",
    "CPU performance, power state and timer tweaks",
    "RAM allocation, prefetch and paging tweaks",
    "NTFS, indexing and disk operation tweaks",
    "Windows services, background tasks and system",
    "Telemetry, data collection and tracking"
};
void (*CAT_ICONS[7])(ImDrawList*,ImVec2,float,ImU32)={I_Net,I_GPU,I_CPU,I_Mem,I_Str,I_Sys,I_Priv};

static void InitStars(float W,float H){
    std::mt19937 rng(0xDEADBEEF);
    for(auto& s:G::Stars){
        s.x=(float)(rng()%10000)/10000.f*W; s.y=(float)(rng()%10000)/10000.f*H;
        s.vy=(float)(rng()%60+15)/3500.f; s.sz=(float)(rng()%3)*.4f+.3f;
        s.a=(float)(rng()%55+8)/255.f; s.ph=(float)(rng()%1000)/1000.f;
    }
}

static void Header(float W){
    auto* dl=ImGui::GetWindowDrawList();
    ImVec2 p=ImGui::GetWindowPos();
    GY(dl,p,{p.x+W,p.y+HDR},C(8,8,22),C(5,5,14));
    // Nebula gradient from corners
    GX(dl,p,{p.x+W*.4f,p.y+HDR},C(30,15,60,50),C(0,0,0,0));
    GX(dl,{p.x+W*.6f,p.y},{p.x+W,p.y+HDR},C(0,0,0,0),C(8,40,80,50));
    // Moving shimmer
    float sh=fmodf(G::T*48.f,W+400)-200;
    GX(dl,{p.x+sh,p.y},{p.x+sh+240,p.y+HDR},C(255,255,255,0),C(255,255,255,5));
    Stars(dl,p,W,HDR);
    // Logo
    float lx=p.x+SB+14;
    if(G::Logo){
        float ls=40,ly=p.y+(HDR-ls)*.5f;
        Glow(dl,{lx+ls*.5f,ly+ls*.5f},ls*.5f,C(80,160,255,160),3);
        dl->AddImage((ImTextureID)G::Logo,{lx,ly},{lx+ls,ly+ls});
        lx+=ls+12;
    }
    // Title
    if(G::FontXL) ImGui::PushFont(G::FontXL);
    dl->AddText(ImGui::GetFont(),G::FontXL?21.f:20.f,{lx,p.y+10},C_TXT,"QuickBoost");
    if(G::FontXL) ImGui::PopFont();
    dl->AddText(ImGui::GetFont(),11.f,{lx,p.y+38},C_DIM,"by Astro  |  discord.gg/astropti  |  v2.0");
    // Admin badge
    float bx=p.x+W-110,by=p.y+(HDR-22)*.5f;
    if(G::Admin){
        dl->AddRectFilled({bx,by},{bx+98,by+22},C(5,18,10),3);
        dl->AddRect({bx,by},{bx+98,by+22},C(25,90,45),3,0,1.f);
        dl->AddCircleFilled({bx+10,by+11},4,C(50,205,90));
        dl->AddText(ImGui::GetFont(),10.5f,{bx+18,by+6},C(45,190,80),"ADMINISTRATOR");
    } else {
        dl->AddRectFilled({bx,by},{bx+98,by+22},C(24,10,5),3);
        dl->AddRect({bx,by},{bx+98,by+22},C(110,45,12),3,0,1.f);
        dl->AddCircleFilled({bx+10,by+11},4,C_AMB);
        dl->AddText(ImGui::GetFont(),10.5f,{bx+18,by+6},C_AMB,"NOT ELEVATED");
    }
    HSep(dl,p.x,p.x+W,p.y+HDR-1,15);
    ImGui::Dummy({W,HDR});
}

static void BannerStrip(float x,float y,float w){
    auto* dl=ImGui::GetWindowDrawList();
    if(G::Banner){
        dl->AddImage((ImTextureID)G::Banner,{x,y},{x+w,y+BNR});
        // Subtle vignette overlay on edges
        GX(dl,{x,y},{x+60,y+BNR},C(0,0,0,180),C(0,0,0,0));
        GX(dl,{x+w-60,y},{x+w,y+BNR},C(0,0,0,0),C(0,0,0,180));
    } else {
        dl->AddRectFilled({x,y},{x+w,y+BNR},C(8,10,22));
        dl->AddText(ImGui::GetFont(),11.f,{x+w*.5f-60,y+BNR*.5f-6},C_DIM,"discord.gg/astropti");
    }
    // Clickable to open Discord
    ImGui::SetCursorScreenPos({x,y});
    ImGui::InvisibleButton("##bnr",{w,BNR});
    if(ImGui::IsItemClicked()) ShellExecuteA(nullptr,"open","https://discord.gg/astropti",nullptr,nullptr,SW_NORMAL);
    if(ImGui::IsItemHovered()){
        dl->AddRectFilled({x,y},{x+w,y+BNR},C(255,255,255,18));
        ImGui::SetTooltip("Click to join discord.gg/astropti");
    }
    HSep(dl,x,x+w,y+BNR-1,12);
}

static void Sidebar(float H,const int counts[7]){
    auto* dl=ImGui::GetWindowDrawList();
    ImVec2 wp=ImGui::GetWindowPos();
    float x=wp.x, y0=wp.y+HDR;
    GY(dl,{x,y0},{x+SB,wp.y+H},C(7,7,18),C(5,5,12));
    dl->AddLine({x+SB,y0},{x+SB,wp.y+H},C_BDR,1.f);
    // Nebula tint in sidebar
    GY(dl,{x,y0},{x+SB,y0+SB*.8f},C(20,10,50,40),C(0,0,0,0));
    // Logo
    if(G::Logo){
        float ls=48,lx=x+(SB-ls)*.5f,ly=y0+10;
        Glow(dl,{lx+ls*.5f,ly+ls*.5f},28,C(80,130,255,130),3);
        dl->AddImage((ImTextureID)G::Logo,{lx,ly},{lx+ls,ly+ls});
        HSep(dl,x+10,x+SB-10,ly+ls+8,14);
    }
    float navY=wp.y+HDR+72.f, btnH=68.f;
    for(int i=0;i<7;i++){
        bool act=(G::Tab==i);
        ImVec2 bMn={x,navY+i*(btnH+2)}, bMx={x+SB,bMn.y+btnH};
        if(act){
            GX(dl,bMn,bMx,C(20,60,140,40),C(0,0,0,0));
            dl->AddRectFilled(bMn,{bMn.x+3,bMx.y},C_BLUE);
            Glow(dl,{bMn.x+14,(bMn.y+bMx.y)*.5f},10,C(50,140,255,180),2);
        }
        ImGui::SetCursorScreenPos(bMn);
        ImGui::InvisibleButton(("##sbn"+std::to_string(i)).c_str(),{SB,btnH});
        if(ImGui::IsItemHovered()&&!act) dl->AddRectFilled(bMn,bMx,C(255,255,255,6));
        if(ImGui::IsItemClicked()) G::Tab=i;
        float isz=26.f,ix=x+(SB-isz)*.5f,iy=bMn.y+10;
        ImU32 ic=act?C_BLUE:C(65,75,130);
        CAT_ICONS[i](dl,{ix,iy},isz,ic);
        ImVec2 ts=ImGui::CalcTextSize(CAT_NAMES[i]);
        dl->AddText({x+(SB-ts.x)*.5f,bMn.y+btnH-20},act?C(130,180,255):C(50,60,110),CAT_NAMES[i]);
        // Badge
        if(counts[i]>0){
            char cb[8]; snprintf(cb,sizeof(cb),"%d",counts[i]);
            ImVec2 cts=ImGui::CalcTextSize(cb);
            float bw=cts.x+8,bh=14,bpx=bMx.x-bw-3,bpy=bMn.y+3;
            dl->AddRectFilled({bpx,bpy},{bpx+bw,bpy+bh},C(10,60,30),4);
            dl->AddRect({bpx,bpy},{bpx+bw,bpy+bh},C(30,100,60),4,0,.8f);
            dl->AddText(ImGui::GetFont(),10.f,{bpx+4,bpy+2},C(60,190,100),cb);
        }
    }
    // RAM/GPU info
    float iy=wp.y+H-STBAR-42;
    HSep(dl,x+8,x+SB-8,iy,12);
    char rb[20]; snprintf(rb,sizeof(rb),"%llu GB RAM",(unsigned long long)Sys::RAM());
    std::string gpu=Sys::GPU();
    const char* gl=gpu=="nvidia"?"NVIDIA":gpu=="amd"?"AMD":"GPU";
    ImVec2 rt=ImGui::CalcTextSize(rb),gt=ImGui::CalcTextSize(gl);
    dl->AddText({x+(SB-rt.x)*.5f,iy+6},C(30,35,75),rb);
    dl->AddText({x+(SB-gt.x)*.5f,iy+22},C(28,32,68),gl);
}

static void StatusBar(float W,float H,std::vector<Opt>* cats){
    auto* dl=ImGui::GetWindowDrawList();
    ImVec2 p=ImGui::GetWindowPos(); float sy=p.y+H-STBAR;
    HSep(dl,p.x,p.x+W,sy,12);
    GY(dl,{p.x,sy},{p.x+W,p.y+H},C(5,5,14),C(4,4,10));
    int total=0; float lo=0,hi=0;
    for(int i=0;i<7;i++) for(auto& o:cats[i]) if(o._on){total++;lo+=o.lo;hi+=o.hi;}
    float tx=p.x+SB+12;
    char buf[128]; snprintf(buf,sizeof(buf),"%d tweaks active",total);
    dl->AddText(ImGui::GetFont(),11.f,{tx,sy+8},C(40,50,100),buf);
    if(total>0){
        snprintf(buf,sizeof(buf),"  |  Est. +%.0f-%.0f%% FPS",lo,hi);
        dl->AddText(ImGui::GetFont(),11.f,{tx+130,sy+8},C(30,100,60),buf);
    }
    std::string gpu=Sys::GPU();
    const char* gl=gpu=="nvidia"?"NVIDIA GPU":gpu=="amd"?"AMD GPU":"GPU";
    ImVec2 gs=ImGui::CalcTextSize(gl);
    dl->AddText(ImGui::GetFont(),11.f,{p.x+W-gs.x-14,sy+8},C(28,32,65),gl);
}

static void Card(Opt& o,int id,const std::string& gpu){
    if(!o._read){o._on=o.check();o._read=true;}
    bool compat=(o.gpu[0]=='\0')||(o.gpu==gpu);
    ImGui::PushID(id);
    float cw=ImGui::GetContentRegionAvail().x;
    ImVec2 mn=ImGui::GetCursorScreenPos(), mx={mn.x+cw,mn.y+CARDH};
    auto* dl=ImGui::GetWindowDrawList();
    Shadow(dl,mn,mx);
    // Card bg
    if(o._on){
        dl->AddRectFilledMultiColor(mn,mx,C(8,20,30),C(5,14,22),C(4,10,18),C(5,14,22));
    } else {
        dl->AddRectFilledMultiColor(mn,mx,C(14,14,30),C(10,10,22),C(7,7,17),C(10,10,22));
    }
    // Star texture overlay on card
    for(int si=0;si<3;si++){
        float sx=mn.x+cw*(.2f+.3f*si), sy=mn.y+CARDH*(.3f+.4f*(si%2));
        dl->AddCircleFilled({sx,sy},.7f,C(200,210,255,(si==1)?18:12));
    }
    dl->AddRect(mn,mx,o._on?C(28,90,160):C_BDR,8.f,0,1.f);
    // Left accent
    ImVec2 aMin={mn.x+1,mn.y+8},aMax={mn.x+8,mn.y+CARDH-8};
    if(o._on){
        GY(dl,aMin,aMax,C_TEAL,C(20,100,70));
        for(int g=4;g>=1;g--) dl->AddRectFilled(aMin,{aMin.x+g*9.f,aMax.y},C(45,210,145,10/g),3.f);
        dl->AddCircleFilled({aMin.x+4,aMin.y+4},4,C_TEAL);
    } else {
        GY(dl,aMin,aMax,C(22,22,50),C(12,12,30));
        dl->AddCircleFilled({aMin.x+4,aMin.y+4},4,C(22,22,50));
    }
    // Hover
    if(ImGui::IsMouseHoveringRect(mn,mx)){
        dl->AddRectFilled(mn,mx,C(255,255,255,4),8);
        GX(dl,mn,{mn.x+60,mx.y},C(80,160,255,12),C(0,0,0,0));
    }
    // Status dot
    ImVec2 dot={mn.x+20,mn.y+CARDH*.5f};
    if(o._on){
        float pulse=(sinf(G::T*2.4f)*.5f+.5f);
        dl->AddCircle(dot,8+pulse*2.5f,C(45,210,145,(int)(45*(1-pulse))),0,1.2f);
        dl->AddCircleFilled(dot,5.5f,C_TEAL);
        dl->AddCircleFilled(dot,2.5f,C(200,255,230));
    } else {
        dl->AddCircleFilled(dot,5,C(16,16,40));
        dl->AddCircle(dot,5,C(28,28,65),0,1.f);
    }
    float r1=mn.y+11,r2=mn.y+40,r3=mn.y+62, rx=mx.x-12;
    // Name
    if(G::FontLg) ImGui::PushFont(G::FontLg);
    ImGui::SetCursorScreenPos({mn.x+33,r1});
    ImGui::PushStyleColor(ImGuiCol_Text,ImVec4(.84f,.88f,1.f,1));
    ImGui::Text("%s",o.name);
    ImGui::PopStyleColor();
    if(G::FontLg) ImGui::PopFont();
    // Tags
    float tagX=mn.x+33+ImGui::CalcTextSize(o.name).x+12;
    auto Tag=[&](const char* lbl,ImU32 bg,ImU32 fg){
        ImVec2 ts=ImGui::CalcTextSize(lbl);
        dl->AddRectFilled({tagX,r1+1},{tagX+ts.x+8,r1+ts.y+3},bg,3);
        dl->AddRect({tagX,r1+1},{tagX+ts.x+8,r1+ts.y+3},fg,3,0,.7f);
        dl->AddText({tagX+4,r1+2},fg,lbl);tagX+=ts.x+14;
    };
    if(o.gpu[0]) Tag(o.gpu[0]=='n'?"NVIDIA":"AMD",C(10,16,30),C(60,90,160));
    if(o.reboot) Tag("REBOOT",C(28,18,5),C_AMB);
    if(o.risky)  Tag("CAUTION",C(30,10,5),C_RED);
    // FPS badge
    {
        char fps[24]; snprintf(fps,sizeof(fps),"+%.0f-%.0f%%",o.lo,o.hi);
        ImVec2 ts=ImGui::CalcTextSize(fps); float bw=ts.x+18,bh=ts.y+6,bx=rx-56-bw-8,by=r1;
        dl->AddRectFilled({bx,by},{bx+bw,by+bh},C(8,10,24),4);
        dl->AddRect({bx,by},{bx+bw,by+bh},C(22,28,65),4,0,.7f);
        dl->AddRectFilled({bx,by},{bx+3,by+bh},o._on?C_TEAL:C(22,22,50),4);
        dl->AddText({bx+8,by+3},o._on?C(100,215,160):C(70,80,140),fps);
    }
    // Toggle
    {
        const float TW=50,TH=24; float tx=rx-TW,ty=r1;
        ImVec2 tp={tx,ty};
        ImU32 track=o._on?C(170,200,255):C(18,18,44);
        dl->AddRectFilled(tp,{tp.x+TW,tp.y+TH},track,TH*.5f);
        if(!o._on) dl->AddRect(tp,{tp.x+TW,tp.y+TH},C(32,32,70),TH*.5f,0,1.f);
        float thumbX=o._on?tp.x+TW-TH*.5f-2:tp.x+TH*.5f+2;
        dl->AddCircleFilled({thumbX,tp.y+TH*.5f},TH*.5f-1,C(0,0,0,55));
        ImU32 thumb=o._on?C(8,8,20):C(55,65,130);
        dl->AddCircleFilled({thumbX,tp.y+TH*.5f},TH*.5f-2.5f,thumb);
        if(o._on){
            dl->AddCircleFilled({thumbX,tp.y+TH*.5f},TH*.5f-4.f,C(120,180,255,90));
            dl->AddCircle({thumbX,tp.y+TH*.5f},TH*.5f-2.5f,C(180,220,255,25),0,1.f);
        }
        if(!compat){
            dl->AddText(ImGui::GetFont(),10.f,{tx+8,ty+7},C(30,32,75),"N/A");
        } else {
            ImGui::SetCursorScreenPos(tp);
            ImGui::InvisibleButton(("t"+std::string(o.id)).c_str(),{TW,TH});
            if(ImGui::IsItemClicked()){
                bool ng=!o._on; bool ok=ng?o.apply():o.revert();
                if(ok) o._on=ng;
                Sys::Notify(std::string(o.name)+(ok?(ng?" applied":" reverted"):" failed"),ok);
            }
        }
    }
    // Description
    if(G::FontMd) ImGui::PushFont(G::FontMd);
    dl->AddText(ImGui::GetFont(),ImGui::GetFontSize(),{mn.x+33,r2},C(80,90,160),o.desc);
    if(G::FontMd) ImGui::PopFont();
    // Caution note
    if(o.risky&&o.caution[0])
        dl->AddText(ImGui::GetFont(),ImGui::GetFontSize(),{mn.x+33,r3},C_AMB,o.caution);
    ImGui::SetCursorScreenPos({mn.x,mn.y+CARDH+7}); ImGui::Dummy({1,1});
    ImGui::PopID();
}

static void ApplyAll(std::vector<Opt>& opts,const char* tab,const std::string& gpu){
    float cw=ImGui::GetContentRegionAvail().x;
    ImVec2 p=ImGui::GetCursorScreenPos(); const float BH=34;
    auto* dl=ImGui::GetWindowDrawList();
    Shadow(dl,p,{p.x+cw,p.y+BH},2);
    bool hov=ImGui::IsMouseHoveringRect(p,{p.x+cw,p.y+BH});
    GY(dl,p,{p.x+cw,p.y+BH},hov?C(12,14,35):C(7,8,22),hov?C(9,11,28):C(5,6,18));
    dl->AddRect(p,{p.x+cw,p.y+BH},hov?C(40,60,140):C(20,24,60),4,0,1.f);
    if(hov) GX(dl,p,{p.x+80,p.y+BH},C(60,120,255,20),C(0,0,0,0));
    // Plus icon
    dl->AddCircle({p.x+18,p.y+BH*.5f},7,C(35,50,120),0,1.2f);
    dl->AddLine({p.x+18,p.y+BH*.5f-3},{p.x+18,p.y+BH*.5f+3},C(60,90,180),1.5f);
    dl->AddLine({p.x+15,p.y+BH*.5f},{p.x+21,p.y+BH*.5f},C(60,90,180),1.5f);
    char lbl[64]; snprintf(lbl,sizeof(lbl),"Apply all %s tweaks",tab);
    ImVec2 ts=ImGui::CalcTextSize(lbl);
    dl->AddText({p.x+(cw-ts.x)*.5f,p.y+(BH-ts.y)*.5f},hov?C(100,130,220):C(45,55,130),lbl);
    ImGui::InvisibleButton("##aa",{cw,BH});
    if(ImGui::IsItemClicked()){
        int n=0;
        for(auto& o:opts){bool c=(o.gpu[0]=='\0')||(o.gpu==gpu);
            if(c&&!o._on){if(o.apply()){o._on=true;n++;}}}
        Sys::Notify("Applied "+std::to_string(n)+" tweaks in "+std::string(tab),true);
    }
    ImGui::Spacing(); ImGui::Spacing();
}

static void Content(float x,float y,float w,float h,std::vector<Opt>* cats,const std::string& gpu){
    auto* dl=ImGui::GetWindowDrawList();
    GY(dl,{x,y},{x+w,y+h},C(6,6,15),C(4,4,11));
    // Nebula blobs in background
    Glow(dl,{x+w*.7f,y+h*.3f},h*.4f,C(20,40,120,60),4);
    Glow(dl,{x+w*.2f,y+h*.7f},h*.3f,C(60,15,90,40),3);

    // Banner strip at top of content
    BannerStrip(x,y,w);

    // Category header
    float hy=y+BNR;
    GY(dl,{x,hy},{x+w,hy+54},C(9,9,22),C(6,6,15));
    HSep(dl,x,x+w,hy+54,14);
    dl->AddRectFilled({x,hy+8},{x+4,hy+46},C_BLUE,2);
    if(G::FontLg) ImGui::PushFont(G::FontLg);
    dl->AddText(ImGui::GetFont(),G::FontLg?16.f:15.f,{x+12,hy+8},C_TXT,CAT_NAMES[G::Tab]);
    if(G::FontLg) ImGui::PopFont();
    dl->AddText(ImGui::GetFont(),10.5f,{x+12,hy+30},C_DIM,CAT_SUBS[G::Tab]);
    // Tab dots
    for(int i=0;i<7;i++){
        float dx=x+w-50+i*9.f,dy=hy+27;
        dl->AddCircleFilled({dx,dy},(G::Tab==i)?4.f:2.5f,(G::Tab==i)?C_BLUE:C(30,35,80));
        ImGui::SetCursorScreenPos({dx-6,dy-6});
        ImGui::InvisibleButton(("##dt"+std::to_string(i)).c_str(),{12,12});
        if(ImGui::IsItemClicked()) G::Tab=i;
    }

    // Scrollable card list
    float listY=hy+58;
    ImGui::SetNextWindowPos({x,listY});
    ImGui::SetNextWindowSize({w,h-(BNR+58)});
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,{12,10});
    ImGui::PushStyleColor(ImGuiCol_ChildBg,ImVec4(0,0,0,0));
    ImGui::BeginChild("##cards",{w,h-(BNR+58)},false,ImGuiWindowFlags_NoBackground);
    ImGui::PopStyleVar(); ImGui::PopStyleColor();

    const char* tabU[7]={"NETWORK","GPU","CPU","MEMORY","STORAGE","SYSTEM","PRIVACY"};
    ApplyAll(cats[G::Tab],tabU[G::Tab],gpu);
    int base=G::Tab*200;
    for(int i=0;i<(int)cats[G::Tab].size();i++) Card(cats[G::Tab][i],base+i,gpu);

    ImGui::EndChild();
}

static void Toasts(float W,float H){
    std::lock_guard<std::mutex> lk(G::TMtx);
    if(G::Toasts.empty()) return;
    auto* dl=ImGui::GetForegroundDrawList();
    float y=H-STBAR-10;
    for(int i=(int)G::Toasts.size()-1;i>=0;i--){
        auto& t=G::Toasts[i]; t.t-=G::DT;
        float a=std::min(1.f,t.t/0.28f); int A=(int)(a*255);
        ImVec2 ts=ImGui::CalcTextSize(t.msg.c_str());
        float nw=ts.x+32,nh=32,nx=W-nw-14;
        dl->AddRectFilled({nx-2,y-nh-2},{nx+nw+2,y+2},C(0,0,0,A/3),6);
        ImU32 bg=t.ok?C(4,14,24,A):C(20,4,8,A);
        ImU32 br=t.ok?C(20,70,140,A):C(120,20,40,A);
        ImU32 tc=t.ok?C(80,160,255,A):C(220,60,80,A);
        dl->AddRectFilled({nx,y-nh},{nx+nw,y},bg,5);
        dl->AddRect({nx,y-nh},{nx+nw,y},br,5,0,1.f);
        dl->AddCircleFilled({nx+13,y-nh*.5f},3,tc);
        dl->AddText({nx+22,y-nh+10},tc,t.msg.c_str());
        y-=nh+5;
    }
    G::Toasts.erase(std::remove_if(G::Toasts.begin(),G::Toasts.end(),[](const G::Toast& t){return t.t<=0;}),G::Toasts.end());
}

static void StartupModal(){
    if(!G::Modal) return;
    ImGui::OpenPopup("##sm");
    ImVec2 ctr=ImGui::GetMainViewport()->GetCenter();
    ImGui::SetNextWindowPos(ctr,ImGuiCond_Always,{.5f,.5f});
    ImGui::SetNextWindowSize({540,290},ImGuiCond_Always);
    ImGui::PushStyleColor(ImGuiCol_PopupBg,ImVec4(0.03f,0.03f,0.07f,1));
    ImGui::PushStyleColor(ImGuiCol_ModalWindowDimBg,ImVec4(0,0,0,.85f));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding,10);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,{0,0});
    if(ImGui::BeginPopupModal("##sm",nullptr,ImGuiWindowFlags_NoTitleBar|ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoMove)){
        auto* dl=ImGui::GetWindowDrawList();
        ImVec2 p=ImGui::GetWindowPos(),sz=ImGui::GetWindowSize();
        // Nebula bg
        Glow(dl,{p.x+sz.x*.5f,p.y+sz.y*.5f},sz.x*.55f,C(30,50,160,60),4);
        dl->AddRectFilled(p,{p.x+sz.x,p.y+sz.y},C(6,6,18),10);
        dl->AddRect(p,{p.x+sz.x,p.y+sz.y},C(28,35,80),10,0,1.f);
        // Stars
        for(int s=0;s<12;s++){
            float sx=p.x+sz.x*(.1f+s*.08f),sy=p.y+sz.y*(.1f+(s%3)*.3f);
            dl->AddCircleFilled({sx,sy},.8f,C(200,210,255,(s%4==0)?45:20));
        }
        // Top blue stripe
        dl->AddRectFilled(p,{p.x+sz.x,p.y+5},C_BLUE,10);
        // Logo
        if(G::Logo){
            float ls=56; ImVec2 lp={p.x+sz.x-ls-18,p.y+18};
            Glow(dl,{lp.x+ls*.5f,lp.y+ls*.5f},30,C(60,130,255,140),3);
            dl->AddImage((ImTextureID)G::Logo,lp,{lp.x+ls,lp.y+ls});
        }
        // Warning icon
        float cx=p.x+42,cy=p.y+65,tr=22.f;
        dl->AddTriangleFilled({cx,cy-tr},{cx-tr*.88f,cy+tr*.65f},{cx+tr*.88f,cy+tr*.65f},C(20,22,60));
        dl->AddTriangle({cx,cy-tr},{cx-tr*.88f,cy+tr*.65f},{cx+tr*.88f,cy+tr*.65f},C_AMB,2.f);
        dl->AddText(ImGui::GetFont(),15.f,{cx-5,cy-9},C_AMB,"!");
        ImGui::SetCursorPos({76,26});
        if(G::FontLg) ImGui::PushFont(G::FontLg);
        ImGui::PushStyleColor(ImGuiCol_Text,ImVec4(.84f,.88f,1.f,1));
        ImGui::Text("Before You Begin");
        ImGui::PopStyleColor();
        if(G::FontLg) ImGui::PopFont();
        ImGui::SetCursorPos({76,50});
        ImGui::PushStyleColor(ImGuiCol_Text,ImVec4(.35f,.40f,.65f,1));
        ImGui::PushTextWrapPos(p.x+sz.x-110);
        ImGui::TextWrapped("Create a Windows Restore Point before applying any tweaks. "
            "This lets you instantly undo all changes if something does not work as expected.");
        ImGui::PopTextWrapPos(); ImGui::PopStyleColor();
        ImGui::SetCursorPos({76,135});
        ImVec2 cp={p.x+76,p.y+135};
        const char* inst="Win+R  ->  sysdm.cpl  ->  System Protection  ->  Create";
        ImVec2 its=ImGui::CalcTextSize(inst);
        dl->AddRectFilled(cp,{cp.x+its.x+16,cp.y+its.y+8},C(8,10,26),4);
        dl->AddRect(cp,{cp.x+its.x+16,cp.y+its.y+8},C(22,28,65),4,0,.8f);
        dl->AddText({cp.x+8,cp.y+4},C(44,55,120),inst);
        ImGui::Dummy({its.x+16,its.y+16});
        ImGui::SetCursorPos({26,198});
        float bw=226,bh=36;
        ImGui::PushStyleColor(ImGuiCol_Button,ImVec4(.06f,.07f,.17f,1));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered,ImVec4(.10f,.12f,.28f,1));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive,ImVec4(.16f,.18f,.38f,1));
        if(ImGui::Button("Open System Protection",{bw,bh})) Sys::Run("control.exe","/name Microsoft.System",0);
        ImGui::SameLine(0,10);
        ImGui::PushStyleColor(ImGuiCol_Text,ImVec4(.80f,.84f,1.f,1));
        if(ImGui::Button("I understand, continue",{bw,bh})){G::Modal=false;ImGui::CloseCurrentPopup();}
        ImGui::PopStyleColor(4);
        ImGui::EndPopup();
    }
    ImGui::PopStyleVar(2); ImGui::PopStyleColor(2);
}
} // UI

// ── Window proc ───────────────────────────────────────────────────────────────
LRESULT WINAPI WndProc(HWND hw,UINT msg,WPARAM wp,LPARAM lp){
    if(ImGui_ImplWin32_WndProcHandler(hw,msg,wp,lp)) return true;
    switch(msg){
    case WM_SIZE:
        if(G::Dev&&wp!=SIZE_MINIMIZED){
            DX::DropRTV();
            G::SC->ResizeBuffers(0,LOWORD(lp),HIWORD(lp),DXGI_FORMAT_UNKNOWN,0);
            DX::MakeRTV();
        } return 0;
    case WM_SYSCOMMAND: if((wp&0xfff0)==SC_KEYMENU) return 0; break;
    case WM_DESTROY: PostQuitMessage(0); return 0;
    case WM_NCHITTEST:{
        LRESULT h=DefWindowProcW(hw,msg,wp,lp);
        if(h==HTCLIENT){POINT pt;GetCursorPos(&pt);ScreenToClient(hw,&pt);
            if(pt.y<(int)HDR&&pt.x>(int)SB) return HTCAPTION;} return h;
    }}
    return DefWindowProcW(hw,msg,wp,lp);
}

// ── WinMain ───────────────────────────────────────────────────────────────────
int APIENTRY WinMain(HINSTANCE,HINSTANCE,LPSTR,int){
    G::Admin=Sys::IsAdmin();
    // With requireAdministrator in manifest, this just shows a diagnostic
    if(!G::Admin)
        MessageBoxA(nullptr,
            "QuickBoost is not running as Administrator.\n"
            "Some tweaks will not apply correctly.\n\n"
            "Right-click QuickBoost.exe and select Run as administrator.",
            "QuickBoost - No Admin Rights", MB_OK|MB_ICONWARNING);

    WNDCLASSEXW wc={sizeof(wc)};
    wc.style=CS_CLASSDC; wc.lpfnWndProc=WndProc;
    wc.hInstance=GetModuleHandleW(nullptr);
    wc.lpszClassName=L"QuickBoostV2";
    RegisterClassExW(&wc);

    HWND hwnd=CreateWindowExW(WS_EX_APPWINDOW,wc.lpszClassName,L"QuickBoost",
        WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX|WS_THICKFRAME,
        40,30,1200,810,nullptr,nullptr,wc.hInstance,nullptr);
    G::Wnd=hwnd;

    BOOL dark=TRUE;
    DwmSetWindowAttribute(hwnd,DWMWA_USE_IMMERSIVE_DARK_MODE,&dark,sizeof(dark));

    // Set window icon (title bar + taskbar)
    G::WinIcon=Sys::MakeIcon(astro_png_data,(int)astro_png_size);
    if(G::WinIcon){
        SendMessageW(hwnd,WM_SETICON,ICON_BIG,(LPARAM)G::WinIcon);
        SendMessageW(hwnd,WM_SETICON,ICON_SMALL,(LPARAM)G::WinIcon);
        SetClassLongPtrW(hwnd,GCLP_HICON,(LONG_PTR)G::WinIcon);
    }

    if(!DX::Init(hwnd)){DX::Kill();UnregisterClassW(wc.lpszClassName,wc.hInstance);return 1;}
    ShowWindow(hwnd,SW_SHOWDEFAULT); UpdateWindow(hwnd);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io=ImGui::GetIO();
    io.ConfigFlags|=ImGuiConfigFlags_NavEnableKeyboard;
    io.IniFilename=nullptr;

    // Load system fonts for a polished look
    const char* fontPaths[]={"C:\\Windows\\Fonts\\segoeui.ttf","C:\\Windows\\Fonts\\verdana.ttf","C:\\Windows\\Fonts\\arial.ttf"};
    const char* boldPaths[]={"C:\\Windows\\Fonts\\segoeuib.ttf","C:\\Windows\\Fonts\\verdanab.ttf","C:\\Windows\\Fonts\\arialbd.ttf"};
    for(auto& fp:fontPaths) if(GetFileAttributesA(fp)!=INVALID_FILE_ATTRIBUTES){
        G::FontSm=io.Fonts->AddFontFromFileTTF(fp,11.5f);
        G::FontMd=io.Fonts->AddFontFromFileTTF(fp,13.5f); break;}
    for(auto& fp:boldPaths) if(GetFileAttributesA(fp)!=INVALID_FILE_ATTRIBUTES){
        G::FontLg=io.Fonts->AddFontFromFileTTF(fp,16.f);
        G::FontXL=io.Fonts->AddFontFromFileTTF(fp,21.f); break;}
    io.Fonts->Build();

    SetStyle();
    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX11_Init(G::Dev,G::Ctx);

    DX::Tex(astro_png_data,(int)astro_png_size,&G::Logo,&G::LW,&G::LH);
    DX::Tex(banner_img_data,(int)banner_img_size,&G::Banner,&G::BW,&G::BH);

    UI::InitStars(1200.f,810.f);

    // Build all 7 category lists
    std::vector<Opt> cats[7];
    cats[0]=MakeNet(); cats[1]=MakeGPU(); cats[2]=MakeCPU();
    cats[3]=MakeMem(); cats[4]=MakeStorage(); cats[5]=MakeSys(); cats[6]=MakePriv();
    std::string gpuType=Sys::GPU();

    auto tp0=std::chrono::high_resolution_clock::now();
    while(G::Run){
        MSG m={};
        while(PeekMessageW(&m,nullptr,0,0,PM_REMOVE)){
            TranslateMessage(&m); DispatchMessageW(&m);
            if(m.message==WM_QUIT) G::Run=false;
        }
        if(!G::Run) break;
        auto tp1=std::chrono::high_resolution_clock::now();
        G::DT=std::chrono::duration<float>(tp1-tp0).count();
        tp0=tp1; G::T+=G::DT;

        ImGui_ImplDX11_NewFrame(); ImGui_ImplWin32_NewFrame(); ImGui::NewFrame();
        float W=io.DisplaySize.x,H=io.DisplaySize.y;

        // Count applied per category for sidebar badges
        int counts[7]={};
        for(int i=0;i<7;i++) for(auto& o:cats[i]) if(o._on) counts[i]++;

        ImGui::SetNextWindowPos({0,0}); ImGui::SetNextWindowSize({W,H});
        ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding,0);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize,0);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,{0,0});
        ImGui::Begin("##root",nullptr,
            ImGuiWindowFlags_NoTitleBar|ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoMove|
            ImGuiWindowFlags_NoScrollbar|ImGuiWindowFlags_NoScrollWithMouse|
            ImGuiWindowFlags_NoBringToFrontOnFocus|ImGuiWindowFlags_NoNav);
        ImGui::PopStyleVar(3);

        // Full-window star field
        Stars(ImGui::GetWindowDrawList(),ImGui::GetWindowPos(),W,H);

        UI::Header(W);
        UI::Sidebar(H,counts);
        UI::Content(SB,HDR,W-SB,H-HDR-STBAR,cats,gpuType);
        UI::StatusBar(W,H,cats);
        UI::StartupModal();
        UI::Toasts(W,H);

        ImGui::End();
        ImGui::Render();

        const float cc[4]={0.024f,0.024f,0.055f,1.f};
        G::Ctx->OMSetRenderTargets(1,&G::RTV,nullptr);
        G::Ctx->ClearRenderTargetView(G::RTV,cc);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        G::SC->Present(1,0);
    }
    ImGui_ImplDX11_Shutdown(); ImGui_ImplWin32_Shutdown(); ImGui::DestroyContext();
    if(G::Logo)   G::Logo->Release();
    if(G::Banner) G::Banner->Release();
    if(G::WinIcon) DestroyIcon(G::WinIcon);
    DX::Kill(); DestroyWindow(hwnd);
    UnregisterClassW(wc.lpszClassName,wc.hInstance);
    return 0;
}
