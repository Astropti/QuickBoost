@echo off
setlocal enabledelayedexpansion
title QuickBoost v2 - Build
echo.
echo  ================================================================
echo    QuickBoost v2.0  by Astro  ^|  discord.gg/astropti
echo  ================================================================
echo.
set VSWHERE="%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist %VSWHERE% set VSWHERE="%ProgramFiles%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist %VSWHERE% ( echo [ERROR] vswhere.exe not found & pause & exit /b 1 )
for /f "usebackq tokens=*" %%i in (`%VSWHERE% -latest -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set VS=%%i
if "!VS!"=="" ( echo [ERROR] VS C++ workload missing. Open VS Installer, tick Desktop development with C++ & pause & exit /b 1 )
echo [OK] Visual Studio: !VS!
call "!VS!\VC\Auxiliary\Build\vcvarsall.bat" x64 >nul 2>&1
echo [OK] x64 environment ready.
where cmake >nul 2>&1
if errorlevel 1 (
    set CM=!VS!\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe
    if not exist "!CM!" ( echo [ERROR] CMake not found & pause & exit /b 1 )
    set PATH=!VS!\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin;!PATH!
)
where ninja >nul 2>&1
if errorlevel 1 (
    if exist "!VS!\Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja\ninja.exe" (
        set PATH=!VS!\Common7\IDE\CommonExtensions\Microsoft\CMake\Ninja;!PATH!
    ) else ( set USE_MSBUILD=1 )
)
if exist build rmdir /s /q build
mkdir build & cd build
echo.
echo [1/2] Configuring (downloads ImGui and stb_image on first run)...
if defined USE_MSBUILD (
    cmake .. -G "Visual Studio 17 2022" -A x64 -DCMAKE_BUILD_TYPE=Release
) else (
    cmake .. -G "Ninja" -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_COMPILER=cl -DCMAKE_CXX_COMPILER=cl
)
if errorlevel 1 ( cd .. & echo [ERROR] Configure failed & pause & exit /b 1 )
echo.
echo [2/2] Compiling...
cmake --build . --config Release --parallel
if errorlevel 1 ( cd .. & echo [ERROR] Compile failed & pause & exit /b 1 )
cd ..
echo.
echo  ================================================================
echo    SUCCESS  -  QuickBoost.exe is ready.
echo    Features: 60+ tweaks, 7 categories, space UI, admin elevation
echo    Share just QuickBoost.exe - fully self-contained.
echo  ================================================================
echo.
pause
